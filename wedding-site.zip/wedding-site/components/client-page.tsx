'use client';

import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  CalendarDays,
  Camera,
  Clock3,
  ExternalLink,
  Flower2,
  Heart,
  Mail,
  MapPin,
  Sparkles
} from 'lucide-react';

const eventDate = new Date('2026-04-18T12:00:00+08:00');

const details = [
  {
    icon: CalendarDays,
    title: 'Tarikh',
    value: 'Sabtu, 18 April 2026',
    sub: '30 Shawwal 1447H'
  },
  {
    icon: Clock3,
    title: 'Masa',
    value: '12:00 PM onwards',
    sub: 'Jamuan santai hingga petang'
  },
  {
    icon: MapPin,
    title: 'Lokasi',
    value: 'No. 21, Kg Baru, 86300 Renggam, Johor',
    sub: 'Majlis di kediaman keluarga'
  }
];

const schedule = [
  { time: '12:00 PM', title: 'Ketibaan Pengantin', note: 'Sambutan keluarga dan tetamu' },
  { time: '1:00 PM – 4:00 PM', title: 'Jamuan & Sesi Santai', note: 'Makan, berbual dan bergambar' },
  { time: '5:00 PM', title: 'Majlis Bersurai', note: 'Penutup dan salam perpisahan' }
];

const gallery = [
  {
    src: 'https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&w=1200&q=80',
    alt: 'Romantic wedding bouquet'
  },
  {
    src: 'https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1200&q=80',
    alt: 'Elegant couple portrait'
  },
  {
    src: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80',
    alt: 'Wedding paper and flowers'
  },
  {
    src: 'https://images.unsplash.com/photo-1523438885200-e635ba2c371e?auto=format&fit=crop&w=1200&q=80',
    alt: 'Wedding table setup'
  }
];

function useCountdown(targetDate: Date) {
  const getTimeLeft = () => {
    const now = new Date();
    const diff = targetDate.getTime() - now.getTime();

    if (diff <= 0) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0 };
    }

    return {
      days: Math.floor(diff / (1000 * 60 * 60 * 24)),
      hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
      minutes: Math.floor((diff / (1000 * 60)) % 60),
      seconds: Math.floor((diff / 1000) % 60)
    };
  };

  const [timeLeft, setTimeLeft] = useState(getTimeLeft());

  useEffect(() => {
    const timer = setInterval(() => setTimeLeft(getTimeLeft()), 1000);
    return () => clearInterval(timer);
  }, [targetDate]);

  return timeLeft;
}

function PaperFrame({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative rounded-[2rem] border border-[#d9c6bb] bg-[#fff9f4]/95 shadow-paper ${className}`}>
      <div className="pointer-events-none absolute inset-3 rounded-[1.45rem] border border-[#eadad2]" />
      <div className="relative">{children}</div>
    </div>
  );
}

function SectionHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description?: string }) {
  return (
    <div className="mx-auto mb-12 max-w-3xl text-center">
      <p className="mb-3 text-xs uppercase tracking-[0.35em] text-[#8d5863]">{eyebrow}</p>
      <h2 className="font-serif text-3xl leading-tight text-[#5c1f2b] md:text-5xl">{title}</h2>
      {description ? <p className="mt-4 text-sm leading-8 text-[#6b4d53] md:text-base">{description}</p> : null}
    </div>
  );
}

function FloralCorners() {
  return (
    <>
      <div className="absolute left-5 top-5 text-[#c78d9a]/55">
        <Flower2 className="h-8 w-8" />
      </div>
      <div className="absolute bottom-5 right-5 rotate-180 text-[#c78d9a]/55">
        <Flower2 className="h-8 w-8" />
      </div>
    </>
  );
}

export default function ClientPage() {
  const countdown = useCountdown(eventDate);

  const countdownItems = useMemo(
    () => [
      { label: 'Hari', value: countdown.days },
      { label: 'Jam', value: countdown.hours },
      { label: 'Minit', value: countdown.minutes },
      { label: 'Saat', value: countdown.seconds }
    ],
    [countdown]
  );

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#f6eee7] text-[#5c1f2b]">
      <div className="pointer-events-none fixed inset-0 opacity-80">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(255,255,255,0.95),_transparent_34%),radial-gradient(circle_at_bottom_right,_rgba(128,32,50,0.09),_transparent_28%)]" />
      </div>

      <main className="relative">
        <section className="px-4 pb-12 pt-6 md:px-8 md:pb-20 md:pt-10">
          <div className="mx-auto max-w-6xl">
            <PaperFrame className="overflow-hidden bg-[#fff7f0] p-4 md:p-8 lg:p-10">
              <FloralCorners />

              <div className="grid items-stretch gap-6 md:gap-8 lg:grid-cols-[1.1fr_0.9fr]">
                <motion.div
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.7 }}
                  className="relative min-h-[430px] overflow-hidden rounded-[1.8rem] md:min-h-[600px]"
                >
                  <img
                    src="https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?auto=format&fit=crop&w=1600&q=80"
                    alt="Elegant wedding floral scene"
                    className="absolute inset-0 h-full w-full object-cover"
                  />
                  <div className="absolute inset-0 bg-[linear-gradient(to_top,rgba(67,16,28,0.88),rgba(67,16,28,0.36),rgba(67,16,28,0.08))]" />
                  <div className="absolute inset-x-0 bottom-0 p-6 text-[#fff8f3] md:p-8">
                    <p className="mb-3 text-xs uppercase tracking-[0.35em] text-[#f3dfd2]">Wedding Invitation</p>
                    <h1 className="font-serif text-4xl leading-tight md:text-6xl">
                      Aiman <span className="text-[#f1d7dc]">&</span> Zuhaira
                    </h1>
                    <p className="mt-4 max-w-lg text-sm leading-7 text-[#fff4ef] md:text-base">
                      A fresh maroon-and-cream invitation inspired by scrapbook layers, paper frames, and soft floral accents.
                    </p>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.7, delay: 0.08 }}
                  className="flex flex-col gap-5"
                >
                  <PaperFrame className="bg-[#fdf6ef] p-6 md:p-7">
                    <div className="mb-4 flex items-center gap-3 text-[#9d5b69]">
                      <Sparkles className="h-5 w-5" />
                      <span className="text-xs uppercase tracking-[0.3em] text-[#8d5863]">Bismillah</span>
                    </div>
                    <p className="text-sm leading-8 text-[#6a414b] md:text-base">
                      Dengan penuh kesyukuran ke hadrat Ilahi, kami menjemput Tuan, Puan, Encik dan Cik untuk memeriahkan majlis perkahwinan kami.
                    </p>

                    <div className="my-6 h-px bg-gradient-to-r from-transparent via-[#d4b2a7] to-transparent" />

                    <div className="grid grid-cols-3 gap-3 text-center">
                      <div className="rounded-[1.4rem] border border-[#ead8cd] bg-white/80 p-4">
                        <p className="text-2xl font-semibold text-[#5c1f2b]">18</p>
                        <p className="mt-1 text-xs uppercase tracking-[0.25em] text-[#8d5863]">April</p>
                      </div>
                      <div className="rounded-[1.4rem] border border-[#ead8cd] bg-white/80 p-4">
                        <p className="text-2xl font-semibold text-[#5c1f2b]">2026</p>
                        <p className="mt-1 text-xs uppercase tracking-[0.25em] text-[#8d5863]">Sabtu</p>
                      </div>
                      <div className="rounded-[1.4rem] border border-[#ead8cd] bg-white/80 p-4">
                        <p className="text-2xl font-semibold text-[#5c1f2b]">12PM</p>
                        <p className="mt-1 text-xs uppercase tracking-[0.25em] text-[#8d5863]">Bermula</p>
                      </div>
                    </div>
                  </PaperFrame>

                  <PaperFrame className="rotate-[-1deg] bg-[#fffaf6] p-6 md:p-7">
                    <div className="mb-4 flex items-center gap-2 text-[#5c1f2b]">
                      <Heart className="h-5 w-5 text-[#a44c62]" />
                      <h3 className="font-serif text-2xl">Designed like a keepsake card</h3>
                    </div>
                    <p className="text-sm leading-8 text-[#6a414b] md:text-base">
                      This version stays easy to use: short sections, clear buttons, gentle motion, and a romantic visual identity without feeling overloaded.
                    </p>
                    <div className="mt-5 flex flex-wrap gap-3">
                      <a href="#rsvp" className="inline-flex items-center gap-2 rounded-full bg-[#5c1f2b] px-5 py-3 text-sm text-[#fff8f3] transition hover:opacity-90">
                        RSVP
                      </a>
                      <a href="#venue" className="inline-flex items-center gap-2 rounded-full border border-[#d1b7b0] bg-white px-5 py-3 text-sm text-[#5c1f2b] transition hover:bg-[#fff7f3]">
                        Location
                      </a>
                    </div>
                  </PaperFrame>
                </motion.div>
              </div>
            </PaperFrame>
          </div>
        </section>

        <section className="px-4 pb-12 md:px-8 md:pb-20">
          <div className="mx-auto max-w-6xl">
            <SectionHeading
              eyebrow="Essentials"
              title="Simple to explore, elegant to remember"
              description="Invitation, details, countdown, schedule, venue, gallery, and RSVP. Enough personality without too many moving parts."
            />
            <div className="grid gap-5 md:grid-cols-3">
              {details.map((item, index) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.title}
                    initial={{ opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    transition={{ duration: 0.45, delay: index * 0.08 }}
                  >
                    <PaperFrame className="h-full bg-[#fffaf5] p-6">
                      <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#f1dde1] text-[#8f4859]">
                        <Icon className="h-5 w-5" />
                      </div>
                      <h3 className="font-serif text-2xl text-[#5c1f2b]">{item.title}</h3>
                      <p className="mt-3 text-base leading-7 text-[#6a414b]">{item.value}</p>
                      <p className="mt-2 text-sm text-[#8d5863]">{item.sub}</p>
                    </PaperFrame>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="px-4 pb-12 md:px-8 md:pb-20">
          <div className="mx-auto grid max-w-6xl items-start gap-6 lg:grid-cols-[0.95fr_1.05fr]">
            <PaperFrame className="sticky top-6 bg-[#fff9f4] p-6 md:p-8">
              <p className="mb-4 text-xs uppercase tracking-[0.3em] text-[#8d5863]">Countdown</p>
              <h3 className="mb-4 font-serif text-3xl text-[#5c1f2b] md:text-4xl">Menanti hari bahagia</h3>
              <p className="mb-6 text-sm leading-8 text-[#6a414b] md:text-base">
                A soft visual countdown keeps the page feeling alive without needing heavy interactive features.
              </p>
              <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                {countdownItems.map((item) => (
                  <div key={item.label} className="rounded-[1.5rem] border border-[#e4d3cb] bg-white/80 p-5 text-center">
                    <p className="text-3xl font-semibold text-[#5c1f2b] md:text-4xl">{item.value}</p>
                    <p className="mt-2 text-xs uppercase tracking-[0.25em] text-[#8d5863]">{item.label}</p>
                  </div>
                ))}
              </div>
            </PaperFrame>

            <PaperFrame className="bg-[#fdf7f1] p-6 md:p-8">
              <p className="mb-4 text-xs uppercase tracking-[0.3em] text-[#8d5863]">Aturcara</p>
              <div className="space-y-4">
                {schedule.map((item, index) => (
                  <div key={item.time} className="rounded-[1.6rem] border border-[#e6d8d1] bg-white/85 p-5 md:p-6">
                    <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                      <div>
                        <p className="text-sm uppercase tracking-[0.25em] text-[#8d5863]">{item.time}</p>
                        <h4 className="mt-2 font-serif text-2xl text-[#5c1f2b]">{item.title}</h4>
                      </div>
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-[#e2c7c5] bg-[#fbf0ed] text-[#8d5863]">
                        {index + 1}
                      </div>
                    </div>
                    <p className="mt-3 leading-7 text-[#6a414b]">{item.note}</p>
                  </div>
                ))}
              </div>
            </PaperFrame>
          </div>
        </section>

        <section id="venue" className="px-4 pb-12 md:px-8 md:pb-20">
          <div className="mx-auto max-w-6xl">
            <SectionHeading
              eyebrow="Venue"
              title="A clear location section with easy actions"
              description="Linking out to Google Maps or Waze is simpler and safer than adding extra map scripts."
            />
            <div className="grid gap-6 lg:grid-cols-[1fr_0.9fr]">
              <PaperFrame className="min-h-[340px] overflow-hidden bg-[#fff9f4]">
                <img
                  src="https://images.unsplash.com/photo-1513279922550-250c2129b13a?auto=format&fit=crop&w=1600&q=80"
                  alt="Elegant event table"
                  className="min-h-[340px] h-full w-full object-cover"
                />
              </PaperFrame>

              <PaperFrame className="bg-[#fffaf5] p-6 md:p-8">
                <div className="mb-4 flex items-center gap-3 text-[#8f4859]">
                  <MapPin className="h-5 w-5" />
                  <p className="text-xs uppercase tracking-[0.3em] text-[#8d5863]">Location Details</p>
                </div>
                <h3 className="font-serif text-3xl text-[#5c1f2b]">Majlis Perkahwinan</h3>
                <p className="mt-4 leading-8 text-[#6a414b]">
                  No. 21, Kg Baru,
                  <br />
                  86300 Renggam, Johor
                </p>
                <p className="mt-4 text-sm leading-8 text-[#6a414b] md:text-base">
                  Make this section practical: one address, one short note, and direct buttons. That keeps it guest-friendly on mobile.
                </p>
                <div className="mt-6 flex flex-wrap gap-3">
                  <a
                    href="https://maps.app.goo.gl/"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-flex items-center gap-2 rounded-full bg-[#5c1f2b] px-5 py-3 text-sm text-[#fff8f3] transition hover:opacity-90"
                  >
                    Google Maps <ExternalLink className="h-4 w-4" />
                  </a>
                  <a
                    href="https://www.waze.com/"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-flex items-center gap-2 rounded-full border border-[#d1b7b0] bg-white px-5 py-3 text-sm text-[#5c1f2b] transition hover:bg-[#fff6f1]"
                  >
                    Waze <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              </PaperFrame>
            </div>
          </div>
        </section>

        <section className="px-4 pb-12 md:px-8 md:pb-20">
          <div className="mx-auto max-w-6xl">
            <SectionHeading
              eyebrow="Gallery"
              title="A curated frame wall, not a busy album"
              description="Styled and limited so the page still feels elegant."
            />
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {gallery.map((item, index) => (
                <motion.div
                  key={item.src}
                  initial={{ opacity: 0, y: 18 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{ duration: 0.45, delay: index * 0.08 }}
                >
                  <PaperFrame className="bg-[#fff8f3] p-3">
                    <div className="aspect-[4/5] overflow-hidden rounded-[1.35rem]">
                      <img src={item.src} alt={item.alt} className="h-full w-full object-cover" />
                    </div>
                  </PaperFrame>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section id="rsvp" className="px-4 pb-12 md:px-8 md:pb-24">
          <div className="mx-auto max-w-5xl">
            <PaperFrame className="overflow-hidden bg-[linear-gradient(135deg,#5c1f2b_0%,#7b3140_100%)] p-6 text-[#fff8f3] md:p-10">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(255,255,255,0.65),_transparent_32%)] opacity-20" />
              <div className="relative grid items-center gap-8 md:grid-cols-[1.05fr_0.95fr]">
                <div>
                  <p className="mb-3 text-xs uppercase tracking-[0.35em] text-[#f1d7dc]">RSVP</p>
                  <h3 className="font-serif text-3xl leading-tight md:text-5xl">Kindly confirm your attendance</h3>
                  <p className="mt-4 max-w-xl text-sm leading-8 text-[#fff4ef] md:text-base">
                    For a safer free setup on GitHub and Vercel, use an external form link instead of storing submissions directly in your site.
                  </p>
                </div>

                <div className="rounded-[1.8rem] border border-white/20 bg-[#fff8f3] p-6 text-[#5c1f2b]">
                  <div className="mb-4 flex items-center gap-3 text-[#8f4859]">
                    <Mail className="h-5 w-5" />
                    <p className="text-xs uppercase tracking-[0.3em] text-[#8d5863]">Simple & Safer</p>
                  </div>
                  <p className="text-sm leading-8 text-[#6a414b] md:text-base">
                    Link this button to your Google Form, Tally form, or WhatsApp RSVP. This avoids building a public database or open API endpoint.
                  </p>
                  <a
                    href="https://forms.gle/"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="mt-6 inline-flex items-center gap-2 rounded-full bg-[#5c1f2b] px-5 py-3 text-sm text-[#fff8f3] transition hover:opacity-90"
                  >
                    Open RSVP Form <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              </div>
            </PaperFrame>
          </div>
        </section>

        <footer className="px-4 pb-10 md:px-8">
          <div className="mx-auto max-w-6xl text-center">
            <div className="inline-flex items-center gap-3 rounded-full border border-[#e2d1c7] bg-white/70 px-5 py-3 text-[#6a414b] shadow-sm">
              <Camera className="h-4 w-4 text-[#8f4859]" />
              <span className="text-sm">With love, Aiman & Zuhaira</span>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
